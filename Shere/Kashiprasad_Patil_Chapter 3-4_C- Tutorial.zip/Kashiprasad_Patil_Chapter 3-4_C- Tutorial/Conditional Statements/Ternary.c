#include<stdio.h>

int main(){
    int age;
    printf("enter age : ");
    scanf("%d",&age);
    age >= 18 ? printf("You are Adult \n") : printf("You are child \n");
     return 0;
}
X
// enter age : 14
 // You are child 

 /*
 enter age : 25
You are Adult
 */